# Kelompok 4 — Paket Overleaf diperbaiki

Penyebab error sebelumnya: Overleaf mengompilasi preamble.tex sebagai dokumen utama. Berkas itu hanya pengaturan, tanpa begin/end document.

Versi ini tidak memiliki preamble.tex atau references.tex terpisah. Setiap berkas .tex adalah dokumen lengkap dan dapat dikompilasi sendiri.

## Langkah yang disarankan
1. Di Overleaf pilih New Project > Upload Project, lalu unggah ZIP versi perbaikan ini sebagai proyek baru. Jangan gabungkan dengan proyek lama agar preamble.tex lama tidak tersisa.
2. Buka Settings/Menu > Main document dan pilih main.tex (laporan MP2).
3. Compiler: pdfLaTeX. Klik Recompile.
4. Untuk MP4, ubah Main document menjadi MP4.tex lalu Recompile.
5. Untuk lampiran, pilih audit_cells.tex lalu Recompile.

Jika ingin memakai proyek lama: hapus preamble.tex dan references.tex lama, ganti ketiga file .tex dengan versi baru, pastikan folder figures lengkap, lalu pilih Main document sesuai laporan. Bila perlu pilih Recompile from scratch.

Isi laporan, identitas anggota, hasil eksperimen, referensi, dan catatan keterbatasan dipertahankan. Hanya pengemasan LaTeX diperbaiki. Gambar tetap dibutuhkan dan sudah disertakan di folder figures.

Laporan merupakan draf berbantuan AI. Sesuai penugasan, kelompok perlu memverifikasi dan menulis interpretasi final sendiri. Kontribusi anggota, tanggal unduh, serta batas integrasi dua sumber dan diskretisasi variabel kontinu tetap perlu dituntaskan sebagaimana dijelaskan pada laporan.
